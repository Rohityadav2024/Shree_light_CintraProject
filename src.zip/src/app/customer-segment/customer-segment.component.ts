import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-segment',
  templateUrl: './customer-segment.component.html',
  styleUrls: ['./customer-segment.component.scss']
})
export class CustomerSegmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
