export interface BusinessPartners {
    CardCode: string;
    CardName: string;    
    id?: number;
}